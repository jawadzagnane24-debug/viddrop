from flask import Flask, request, jsonify, send_from_directory
from pathlib import Path
import os
import re
import yt_dlp

BASE_DIR = Path(__file__).resolve().parent
app = Flask(__name__, static_folder=None)

def valid_tiktok_url(value):
    # Only allow TikTok URLs to prevent arbitrary URL fetching (SSRF).
    from urllib.parse import urlparse
    try:
        p = urlparse(value)
        host = (p.hostname or "").lower()
        return p.scheme == "https" and (host == "tiktok.com" or host.endswith(".tiktok.com"))
    except Exception:
        return False

@app.get("/")
def index():
    return send_from_directory(BASE_DIR, "index.html")

@app.post("/api/resolve")
def resolve():
    body = request.get_json(silent=True) or {}
    url = str(body.get("url", "")).strip()
    if not valid_tiktok_url(url):
        return jsonify(error="رابط TikTok غير صالح."), 400

    # yt-dlp is a best-effort extractor. TikTok may change its systems or restrict a post.
    opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "extractor_args": {"tiktok": {"api_hostname": ["api22-normal-c-useast1a.tiktokv.com"]}},
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
        direct = info.get("url")
        return jsonify({
            "title": info.get("title") or "TikTok video",
            "author": info.get("uploader") or info.get("creator") or "",
            "thumbnail": info.get("thumbnail") or "",
            "webpage_url": info.get("webpage_url") or url,
            # The extractor URL can expire; it is a best-effort direct media URL.
            "download_url": direct or ""
        })
    except Exception:
        return jsonify(error="ما قدرناش نستخرجو الفيديو. ممكن يكون خاص، محذوف، أو TikTok بدّل طريقة الوصول. جرّب رابط عام آخر."), 422

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
