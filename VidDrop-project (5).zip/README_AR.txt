VidDrop — نشر المشروع من هاتف Android

الملفات:
- index.html: واجهة الموقع
- app.py: خادم Flask ونقطة API
- requirements.txt: مكتبات Python اللازمة

النشر عبر GitHub + Render:
1) فك ضغط VidDrop-project.zip على الهاتف باستعمال تطبيق ملفات يدعم ZIP.
2) افتح github.com في Chrome وسجّل الدخول أو أنشئ حساباً.
3) أنشئ مستودعاً جديداً باسم viddrop واجعله Private إذا تفضّل.
4) داخل المستودع اضغط Add file ثم Upload files، وارفع الملفات الثلاثة مباشرة (index.html و app.py و requirements.txt و README_AR.txt) من داخل المجلد المفكوك. لا ترفع ملف ZIP وحده.
5) اضغط Commit changes لحفظ الملفات.
6) افتح render.com وأنشئ حساباً، ثم New + > Web Service، واربط GitHub واختر مستودع viddrop.
7) الإعدادات:
   Runtime/Language: Python 3
   Build Command: pip install -r requirements.txt
   Start Command: gunicorn app:app
   Instance Type: Free (إذا كان متاحاً في حسابك)
8) اضغط Deploy وانتظر حتى تظهر حالة Live. ستحصل على رابط مثل https://اسم-الخدمة.onrender.com

ملاحظات:
- خدمة Render المجانية قد توقف الخادم بعد فترة عدم نشاط، وقد يستغرق أول فتح وقتاً أطول.
- هذا الخادم يحاول استخراج معلومات وروابط الوسائط بواسطة yt-dlp، لكنه قد يفشل إذا كان الفيديو خاصاً أو محذوفاً أو إذا غيّرت TikTok طريقة الوصول.
- لا تضع كلمات مرور أو مفاتيح سرية داخل ملفات الموقع أو GitHub.
- قبل الاستخدام العام، راجع قوانين حقوق النشر وشروط المنصة، ولا تستخدمه إلا للمحتوى الذي تملك حق تنزيله.
